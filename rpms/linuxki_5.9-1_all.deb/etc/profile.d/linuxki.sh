export PATH=$PATH:/opt/linuxki
